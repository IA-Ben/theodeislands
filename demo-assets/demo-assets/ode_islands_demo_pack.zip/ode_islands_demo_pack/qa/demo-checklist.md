# Presenter Demo Checklist (5 mins)

- [ ] Load app → Shift+D to open Presenter Mode.
- [ ] Click **Run 5‑minute demo**.
- [ ] Callouts:
  - Feed explain chip (“Because you unlocked…”).
  - Chapter completion → reward toast.
  - Micro‑game auto pass → grade toast.
  - Wallet shows new items (one holographic if set complete).
  - Phase toggle to Show → Venue + Merch cards surface.
  - Phase to Post → After Recap montage.
- [ ] Reset session; repeat if needed.
